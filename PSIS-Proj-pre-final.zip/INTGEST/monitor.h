#ifndef MONITOR_h
#define MONITOR_h

#include "structs.h"


#endif